public interface User {
	String getName();
	void setName(String name);
	
	int getFacultyNumber();
	void setFacultyNumber(int facultyNumber);
}